package p;
import java.sql.*;
import com.opensymphony.xwork2.ActionSupport;


@SuppressWarnings("serial")
public class AddAirFrame extends ActionSupport 
{
	String code, description;
	String msg1, msg2;

public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getMsg1() {
		return msg1;
	}

	public void setMsg1(String msg1) {
		this.msg1 = msg1;
	}

	public String getMsg2() {
		return msg2;
	}

	public void setMsg2(String msg2) {
		this.msg2 = msg2;
	}

public String execute()
{
try
{
Class.forName("oracle.jdbc.driver.OracleDriver");
Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","manager");
PreparedStatement ps=con.prepareStatement("insert into airframe values(?,?)");
ps.setString(1,code);
ps.setString(2,description);

ps.executeUpdate();          

con.commit();

ps.close();
con.close();
setMsg1("Air Frame Added Successfully..............");
return "success";

}
catch(Exception e){
	e.printStackTrace();
	setMsg2("Please Check your Input...........");
		return "fail";
}

}

}