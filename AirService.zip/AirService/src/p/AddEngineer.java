package p;

import java.sql.*;

import com.opensymphony.xwork2.ActionSupport;

@SuppressWarnings("serial")
public class AddEngineer extends ActionSupport {

	String eid, name, dates, email, phone, address;
	String msg1, msg2;

	public String getEid() {
		return eid;
	}

	public void setEid(String eid) {
		this.eid = eid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDates() {
		return dates;
	}

	public void setDates(String dates) {
		this.dates = dates;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getMsg1() {
		return msg1;
	}

	public void setMsg1(String msg1) {
		this.msg1 = msg1;
	}

	public String getMsg2() {
		return msg2;
	}

	public void setMsg2(String msg2) {
		this.msg2 = msg2;
	}

	public String execute()
	{
	try
	{
	Class.forName("oracle.jdbc.driver.OracleDriver");
	Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","manager");
	PreparedStatement ps=con.prepareStatement("insert into engineer values(?,?,?,?,?,?)");
	ps.setString(1,eid);
	ps.setString(2,name);
	ps.setString(3,dates);
	ps.setString(4,email);
	ps.setString(5,phone);
	ps.setString(6,address);

	ps.executeUpdate();          

	con.commit();

	ps.close();
	con.close();
	setMsg1("Registration Completed Successfully..............");
	return "success";

	}
	catch(Exception e){
		e.printStackTrace();
		setMsg2("Please Check your Input...........");
			return "fail";
	}

	}

}
